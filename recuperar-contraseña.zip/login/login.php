<?php
session_start();
header('Content-Type: application/json');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

// Credenciales (env primero, si no hay usa las del proyecto)
$host   = getenv('DB_HOST') ?: 'localhost';
$dbname = getenv('DB_NAME') ?: 'u772860605_DATAK';
$user   = getenv('DB_USER') ?: 'u772860605_JACEUF';
$pass   = getenv('DB_PASSWORD') ?: 'j.2.4.6.4.R';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error de conexión a la base de datos']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Solicitud inválida']);
    exit;
}

$action = (string) ($data['action'] ?? 'login');

// ---------- helpers ----------
function passwordIsTooSimple(string $password, string $email, ?string $nombre = null): ?string
{
    if (strlen($password) < 8) {
        return 'La contraseña debe tener mínimo 8 caracteres';
    }
    if (preg_match('/^[a-zA-Z]+$/', $password)) {
        return 'La contraseña no puede ser solo letras';
    }
    if (preg_match('/^[0-9]+$/', $password)) {
        return 'La contraseña no puede ser solo números';
    }
    if (preg_match('/^[^a-zA-Z0-9]+$/', $password)) {
        return 'La contraseña no puede ser solo símbolos';
    }

    $common = [
        '12345678', 'password', '123456789', 'qwerty', 'abc123',
        'password123', 'admin', 'letmein', 'welcome', '12345',
        '1234567890', 'qwerty123', '1q2w3e4r', 'iloveyou', 'monkey'
    ];
    $passwordLower = strtolower($password);
    foreach ($common as $c) {
        if ($passwordLower === strtolower($c)) {
            return 'La contraseña es demasiado común';
        }
    }

    if ($nombre) {
        $nombreLower = strtolower($nombre);
        $parts = explode(' ', $nombreLower);
        if (strpos($passwordLower, $nombreLower) !== false || strpos($passwordLower, $parts[0]) !== false) {
            return 'La contraseña no puede incluir tu nombre';
        }
    }

    $partsEmail = explode('@', $email);
    $local = strtolower($partsEmail[0] ?? '');
    if ($local !== '' && strpos($passwordLower, $local) !== false) {
        return 'La contraseña no puede incluir tu correo';
    }

    return null;
}

// ========== ENVIAR CÓDIGO DE RECUPERACIÓN ==========
if ($action === 'send_recover_code') {
    $email = strtolower(trim((string) ($data['email'] ?? '')));

    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Ingresa un correo válido']);
        exit;
    }

    $stmt = $pdo->prepare('SELECT id_usuario, nombre, email FROM Usuarios WHERE LOWER(email) = :email LIMIT 1');
    $stmt->execute([':email' => $email]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    // Por seguridad no revelamos si el correo existe o no
    if (!$usuario) {
        echo json_encode([
            'success' => true,
            'message' => 'Si el correo está registrado, recibirás un código en unos minutos.'
        ]);
        exit;
    }

    // Invalidar códigos anteriores
    $pdo->prepare('UPDATE password_resets SET usado = 1 WHERE email = :email AND usado = 0')
        ->execute([':email' => $email]);

    $codigo = str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $expira = (new DateTime('+15 minutes'))->format('Y-m-d H:i:s');

    $ins = $pdo->prepare(
        'INSERT INTO password_resets (email, codigo, expira_en, usado) VALUES (:email, :codigo, :expira, 0)'
    );
    $ins->execute([
        ':email'  => $email,
        ':codigo' => $codigo,
        ':expira' => $expira
    ]);

    // Intentar enviar correo
    $asunto = 'Código de recuperación - Koaly';
    $cuerpo = "Hola {$usuario['nombre']},\n\n"
            . "Tu código de recuperación es: {$codigo}\n\n"
            . "Válido por 15 minutos.\n"
            . "Si no pediste esto, ignora el mensaje.\n\n"
            . "— Equipo Koaly";
    $headers = "From: noreply@koaly.app\r\n"
             . "Reply-To: noreply@koaly.app\r\n"
             . "Content-Type: text/plain; charset=UTF-8\r\n";

    $enviado = @mail($email, $asunto, $cuerpo, $headers);

    $respuesta = [
        'success' => true,
        'message' => $enviado
            ? 'Código enviado. Revisa tu correo.'
            : 'Código generado. (El servidor de correo no está configurado; usa el código de prueba)'
    ];

    // Si mail() falla, devolvemos el código para que puedas probar (quítalo en producción real)
    if (!$enviado) {
        $respuesta['debug_code'] = $codigo;
    }

    echo json_encode($respuesta);
    exit;
}

// ========== RESTABLECER CONTRASEÑA CON CÓDIGO ==========
if ($action === 'reset_password') {
    $email    = strtolower(trim((string) ($data['email'] ?? '')));
    $codigo   = trim((string) ($data['code'] ?? ''));
    $password = (string) ($data['password'] ?? '');

    if ($email === '' || $codigo === '' || $password === '') {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Completa todos los campos']);
        exit;
    }

    $stmt = $pdo->prepare('SELECT id_usuario, nombre, email FROM Usuarios WHERE LOWER(email) = :email LIMIT 1');
    $stmt->execute([':email' => $email]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Código inválido o expirado']);
        exit;
    }

    $errorPass = passwordIsTooSimple($password, $email, $usuario['nombre']);
    if ($errorPass !== null) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => $errorPass]);
        exit;
    }

    // Buscar código válido
    $stmt = $pdo->prepare(
        'SELECT id FROM password_resets
         WHERE email = :email AND codigo = :codigo AND usado = 0 AND expira_en > NOW()
         ORDER BY id DESC LIMIT 1'
    );
    $stmt->execute([':email' => $email, ':codigo' => $codigo]);
    $reset = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$reset) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Código inválido o expirado']);
        exit;
    }

    $newHash = password_hash($password, PASSWORD_DEFAULT);

    $pdo->beginTransaction();
    try {
        $upd = $pdo->prepare(
            'UPDATE Usuarios SET contrasena_hash = :hash, debe_cambiar = 0 WHERE id_usuario = :id'
        );
        $upd->execute([':hash' => $newHash, ':id' => $usuario['id_usuario']]);

        $pdo->prepare('UPDATE password_resets SET usado = 1 WHERE id = :id')
            ->execute([':id' => $reset['id']]);

        $pdo->commit();
    } catch (Exception $e) {
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'No se pudo actualizar la contraseña']);
        exit;
    }

    echo json_encode([
        'success' => true,
        'message' => 'Contraseña restablecida correctamente. Ya puedes iniciar sesión.'
    ]);
    exit;
}

// ========== CAMBIO DE CONTRASEÑA (primer login / desde sesión) ==========
if ($action === 'change_password' || $action === 'cambiar_contrasena') {
    // Soporta ambos nombres de action
    $password = (string) ($data['password'] ?? $data['nueva_contrasena'] ?? '');
    $emailFromBody = strtolower(trim((string) ($data['email'] ?? '')));

    // Preferir sesión
    $idUsuario = $_SESSION['id_usuario'] ?? null;

    if ($idUsuario) {
        $stmt = $pdo->prepare('SELECT id_usuario, nombre, email, id_rol FROM Usuarios WHERE id_usuario = :id LIMIT 1');
        $stmt->execute([':id' => $idUsuario]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    } elseif ($emailFromBody !== '') {
        $stmt = $pdo->prepare('SELECT id_usuario, nombre, email, id_rol FROM Usuarios WHERE LOWER(email) = :email LIMIT 1');
        $stmt->execute([':email' => $emailFromBody]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Sesión no válida']);
        exit;
    }

    if (!$usuario) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Usuario no encontrado']);
        exit;
    }

    $errorPass = passwordIsTooSimple($password, $usuario['email'], $usuario['nombre']);
    if ($errorPass !== null) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => $errorPass]);
        exit;
    }

    $newHash = password_hash($password, PASSWORD_DEFAULT);
    $upd = $pdo->prepare(
        'UPDATE Usuarios SET contrasena_hash = :hash, debe_cambiar = 0 WHERE id_usuario = :id'
    );
    $upd->execute([':hash' => $newHash, ':id' => $usuario['id_usuario']]);

    echo json_encode([
        'success' => true,
        'message' => 'Contraseña actualizada correctamente'
    ]);
    exit;
}

// ========== LOGIN NORMAL ==========
$email    = strtolower(trim((string) ($data['email'] ?? '')));
$password = (string) ($data['password'] ?? '');

if ($email === '' || $password === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Ingresa un correo y contraseña válidos']);
    exit;
}

$stmt = $pdo->prepare(
    "SELECT u.id_usuario, u.nombre, u.email, u.contrasena_hash, u.id_rol,
            u.id_sucursal, u.estado, u.debe_cambiar, r.nombre_rol,
            s.nombre AS sucursal_nombre, s.estado AS sucursal_estado
     FROM Usuarios u
     INNER JOIN Roles r ON r.id_rol = u.id_rol
     LEFT JOIN Sucursales s ON s.id_sucursal = u.id_sucursal
     WHERE LOWER(u.email) = :email
     LIMIT 1"
);
$stmt->execute([':email' => $email]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Correo o contraseña incorrectos']);
    exit;
}

if ($usuario['estado'] !== 'Activo') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => "Usuario en estado: {$usuario['estado']}. No puede iniciar sesión."]);
    exit;
}

$passwordIsValid = password_verify($password, $usuario['contrasena_hash']);

// Migra registros antiguos sin hash
if (!$passwordIsValid && substr($usuario['contrasena_hash'], 0, 1) !== '$') {
    $passwordIsValid = hash_equals($usuario['contrasena_hash'], $password);
    if ($passwordIsValid) {
        $newHash = password_hash($password, PASSWORD_DEFAULT);
        $pdo->prepare('UPDATE Usuarios SET contrasena_hash = :h WHERE id_usuario = :id')
            ->execute([':h' => $newHash, ':id' => $usuario['id_usuario']]);
    }
}

if (!$passwordIsValid) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Correo o contraseña incorrectos']);
    exit;
}

if ((int) $usuario['id_rol'] !== 1 && $usuario['id_sucursal'] === null) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'La cuenta no tiene una sucursal asignada']);
    exit;
}

if ($usuario['id_sucursal'] !== null && $usuario['sucursal_estado'] !== 'Activa') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'La sucursal no está disponible']);
    exit;
}

$_SESSION['id_usuario'] = $usuario['id_usuario'];
$_SESSION['id_rol']     = $usuario['id_rol'];
$_SESSION['email']      = $usuario['email'];

unset($usuario['contrasena_hash']);

$debeCambiar = (bool) $usuario['debe_cambiar'];

echo json_encode([
    'success'      => true,
    'message'      => $debeCambiar ? 'Debes cambiar tu contraseña' : 'Inicio de sesión exitoso',
    'debe_cambiar' => $debeCambiar,
    'user'         => $usuario
]);
